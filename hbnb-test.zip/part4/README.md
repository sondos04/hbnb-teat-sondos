Part 4 - Simple Web Client
